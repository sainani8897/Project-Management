import ErrorPage from './ErrorPage';

export default ErrorPage;
