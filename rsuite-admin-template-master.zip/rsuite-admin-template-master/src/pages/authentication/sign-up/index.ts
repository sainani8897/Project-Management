import SignUp from './SignUp';

export default SignUp;
