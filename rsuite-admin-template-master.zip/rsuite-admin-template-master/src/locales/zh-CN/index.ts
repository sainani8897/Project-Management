export default {
  id: 'zh-CN',
  error404: '该页面不存在',
  error500: '服务器没有响应'
};
