import en from './en-US';
import zh from './zh-CN';

export default {
  en: en,
  zh: zh
};
